package com.example.rajeshaatrayan.fingerprintauthentication;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.KeyguardManager;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class MainActivity extends AppCompatActivity {
    /**
     * private data members of the layout
     */
    private TextView textView_1;
    private ImageView imageView;
    private TextView textView_2;
    //FingerPrintManager ref variable to check wether the device has the finger print scanner!
    private FingerprintManager fingerprintManager;
    //keyguragManager ref variable to check wether your device lock screen is protected with one security prototype
    private KeyguardManager keyguardManager;

    //keystore store a unique key that will be generated for authentication
    private KeyStore keyStore;
    private Cipher cipher;
    private String KEY_NAME = "AndroidKey";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //grabbing the references of the views
        textView_1 = (TextView) findViewById(R.id.textView);
        imageView = (ImageView) findViewById(R.id.image);
        textView_2 = (TextView) findViewById(R.id.bottom_tv);
        //To integrate the fingerprint scanner into our app we must follow the below 5 steps

        // STEP 1: Android version should be greater than or equal to Marshmallow 6.0
        //STEP 2: Check wether the device has finger print scanner
        // STEP 3:Check wether you have permission to use finger print scanner in your app
        //STEP 4:Your lockscreen should be secured with atleat one type of security prototype for you to use fp scanner
        //TODO STEP 5:Atleast one finger print must be registered on your device

        //we must pass all the above constraints inorder to run our app with a integrated fp scanner!

        /**
         * check wether our sdk version is >= Marshmallow ie..23
         */

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {//step1-if it is true go inside

            //intializing the fingerprintManger ref variable by grabbing the system services
            fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);
            keyguardManager=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);

            if (!fingerprintManager.isHardwareDetected()) {//step 2 if hardware is not detected
                textView_2.setText("Fingerprint scanner is not detected in your device");

            }
            /**
             * checking wether you have persimission  to use fp scanner for your app
             * ContextCompat.checkSelfPermission()-->takes two arg 1.context, 2.permission
             */
            else if (ContextCompat.checkSelfPermission(this, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) {
                //if you dont have permission then
                textView_2.setText("You dont have permission to acees finger print scanner on your device");
            }
            else if(!keyguardManager.isKeyguardSecure()){
                //if the lock screen is not protected
                textView_2.setText("Secure your lockscreen");

            }
            else if(!fingerprintManager.hasEnrolledFingerprints()){
                textView_2.setText("Add a fingerprint");
            }
            else{
                //finally here we are ready to test our finger
                textView_2.setText("Place your finger on the scanner to proceed");
                generateKey();
                if(cipherInit()){
                   FingerprintManager.CryptoObject cryptoObject=new FingerprintManager.CryptoObject(cipher);

                FingerPrintHandler fingerPrintHandler=new FingerPrintHandler(this);
                //if you want to pass null as crypto object then dont use generate and keystroke methods!
                fingerPrintHandler.startAuth(fingerprintManager,cryptoObject);}
            }



        }


    }

    /**
     * just copy and paste the below method for encrytpion purpose!
     */
    private void generateKey() {

        try {

            keyStore = KeyStore.getInstance("AndroidKeyStore");
            KeyGenerator keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");

            keyStore.load(null);
            keyGenerator.init(new
                    KeyGenParameterSpec.Builder(KEY_NAME,
                    KeyProperties.PURPOSE_ENCRYPT |
                            KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                    .setUserAuthenticationRequired(true)
                    .setEncryptionPaddings(
                            KeyProperties.ENCRYPTION_PADDING_PKCS7)
                    .build());
            keyGenerator.generateKey();

        } catch (KeyStoreException | IOException | CertificateException
                | NoSuchAlgorithmException | InvalidAlgorithmParameterException
                | NoSuchProviderException e) {

            e.printStackTrace();

        }

    }

    @TargetApi(Build.VERSION_CODES.M)
    public boolean cipherInit() {
        try {
            cipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/" + KeyProperties.BLOCK_MODE_CBC + "/" + KeyProperties.ENCRYPTION_PADDING_PKCS7);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new RuntimeException("Failed to get Cipher", e);
        }


        try {

            keyStore.load(null);

            SecretKey key = (SecretKey) keyStore.getKey(KEY_NAME,
                    null);

            cipher.init(Cipher.ENCRYPT_MODE, key);

            return true;

        } catch (KeyPermanentlyInvalidatedException e) {
            return false;
        } catch (KeyStoreException | CertificateException | UnrecoverableKeyException | IOException | NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException("Failed to init Cipher", e);
        }

    }
}
