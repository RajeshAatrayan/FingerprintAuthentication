package com.example.rajeshaatrayan.fingerprintauthentication;

import android.app.Activity;
import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.CancellationSignal;
import android.support.v4.content.ContextCompat;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by RajeshAatrayan on 08-07-2018.
 */
//this class helps us to implement the functionality methods of the finger print scanner
class FingerPrintHandler extends FingerprintManager.AuthenticationCallback {
    private  Context context;
    public FingerPrintHandler(Context context) {
        this.context=context;
    }

    /**
     * Why crypto object is needed for Android fingerprint authentication?
     *
     *You don't have to. You can make fingerprint authentication without a CryptoObject, just pass a null value. Then won't have to mess with keystore and other stuff.

     The only use of a CryptoObject in a Fingerprint Authentication context is to know if a new fingerprint was added since last time the user authenticated via fingerprint.
     *
     *
     * @param fingerprintManager
     * @param cryptoObject
     */
    public void startAuth(FingerprintManager fingerprintManager,FingerprintManager.CryptoObject cryptoObject){

/**
 * authenticate takes  args 1.cryptoobject 2.cancellationsignal 3.flags 4.Authentication call backs 5.handler
 */
        CancellationSignal cancellationSignal=new CancellationSignal();
        fingerprintManager.authenticate(cryptoObject,cancellationSignal,0,this,null);
    }

    @Override
    public void onAuthenticationError(int errorCode, CharSequence errString) {
        this.update("Authentication Error "+errString,false);
    }

    @Override
    public void onAuthenticationFailed() {
        this.update("Authentication Failed",false);
    }

    @Override
    public void onAuthenticationHelp(int helpCode, CharSequence helpString) {
        this.update(helpString,false);
    }

    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
        this.update("You can now acess the app",true);
    }

    private void update(CharSequence helpString, boolean b) {
        TextView textView_2=(TextView)((Activity)context).findViewById(R.id.bottom_tv);
        ImageView imageView=(ImageView)((Activity)context).findViewById(R.id.image);
        textView_2.setText(helpString);
        if(b==false){
            textView_2.setTextColor(ContextCompat.getColor(context,R.color.colorAccent));
        }
        else
        {
            textView_2.setTextColor(ContextCompat.getColor(context,R.color.colorPrimary));
            imageView.setImageResource(R.mipmap.action_done);
        }


    }

}
